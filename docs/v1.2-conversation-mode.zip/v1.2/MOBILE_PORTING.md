# 📱 MOBILE PORTING GUIDE — v1.2
# Direction Toggle + MicState + Conversation Mode

## State additions (all platforms)

```
direction:        "RU_DE" | "DE_RU"
micState:         "Idle" | "Recording" | "Processing"
conversationMode: Boolean
```

---

## Direction Toggle

### Swift
```swift
enum Direction { case ruDe, deRu }
var direction: Direction = .ruDe

var targetLanguage: String {
    direction == .ruDe ? "DE" : "RU"
}
var sourceLang: String {
    direction == .ruDe ? "ru-RU" : "de-DE"
}

func toggleDirection() {
    direction = direction == .ruDe ? .deRu : .ruDe
    inputText = ""; translatedText = ""
}
```

### Kotlin
```kotlin
enum class Direction { RU_DE, DE_RU }
var direction = Direction.RU_DE

val targetLanguage get() = if (direction == Direction.RU_DE) "DE" else "RU"
val sourceLang     get() = if (direction == Direction.RU_DE) "ru-RU" else "de-DE"

fun toggleDirection() {
    direction = if (direction == Direction.RU_DE) Direction.DE_RU else Direction.RU_DE
    _state.update { it.copy(inputText = "", translatedText = "") }
}
```

---

## MicState Machine

### Swift
```swift
enum MicState { case idle, recording, processing }
@Published var micState: MicState = .idle

func toggleMic() {
    switch micState {
    case .idle:
        startRecording()      // AVAudioRecorder.record()
        micState = .recording
    case .recording:
        stopRecording()       // audioRecorder.stop()
        micState = .processing
        Task { await sendVoice() }
    case .processing:
        break // ignore
    }
}
```

### Kotlin
```kotlin
enum class MicState { IDLE, RECORDING, PROCESSING }

fun toggleMic() = when (_state.value.micState) {
    MicState.IDLE -> {
        startAudioRecord()
        _state.update { it.copy(micState = MicState.RECORDING) }
    }
    MicState.RECORDING -> {
        stopAudioRecord()
        _state.update { it.copy(micState = MicState.PROCESSING) }
        viewModelScope.launch { sendVoice() }
    }
    MicState.PROCESSING -> Unit // ignore
}
```

---

## Partial / Debounced Translation

### Swift
```swift
private var debounceTask: Task<Void, Never>?

func onPartialTranscript(_ text: String) {
    inputText = text
    debounceTask?.cancel()
    debounceTask = Task {
        try? await Task.sleep(nanoseconds: 1_500_000_000) // 1.5s
        if !Task.isCancelled { await translatePartial(text) }
    }
}
```

### Kotlin
```kotlin
private var debounceJob: Job? = null

fun onPartialTranscript(text: String) {
    _state.update { it.copy(inputText = text) }
    debounceJob?.cancel()
    debounceJob = viewModelScope.launch {
        delay(1500)
        translatePartial(text)
    }
}
```

---

## No Auto-Stop (continuous recording)

### iOS: SFSpeechRecognizer
```swift
// taskHints = .dictation → continuous
recognitionRequest.shouldReportPartialResults = true
// Don't set timeout. Stop ONLY on toggleMic()
```

### Android: SpeechRecognizer
```kotlin
intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 999_999L)
intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 999_999L)
// Stop ONLY on toggleMic()
recognizer.stopListening()
```

---

## Conversation Mode

Both platforms: push a new View/Screen with:
- Split layout: source zone (top) + translation zone (bottom)
- Font 1.6x–2x of normal
- Only mic + direction controls visible
- Auto-scroll to bottom on text change
- Back button exits to normal mode
